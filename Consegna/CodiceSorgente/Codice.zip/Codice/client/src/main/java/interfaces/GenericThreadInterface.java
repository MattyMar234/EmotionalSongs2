package interfaces;

public interface GenericThreadInterface {

    void execute(Object ...data);

}
