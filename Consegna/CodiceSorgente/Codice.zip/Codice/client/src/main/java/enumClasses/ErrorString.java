package enumClasses;

/**
 * Classe enum usata per rappresentare degli errori.
 */
public enum ErrorString {
    INVALID_EMAIL,
    INVALID_PASSWORD,
    INVALID_NICKNAME;
}
