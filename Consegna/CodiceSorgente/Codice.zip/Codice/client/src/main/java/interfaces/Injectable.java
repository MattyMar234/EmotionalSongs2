package interfaces;

public interface Injectable {

    public void injectData(Object...data);
    public void init(Object...data);
    
}
