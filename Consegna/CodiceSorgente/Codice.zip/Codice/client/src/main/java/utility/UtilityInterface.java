package utility;

public interface UtilityInterface {

    public void execute(Object... args);
    
}
