package Exceptions;

public class InvalidArgsExeption  extends Exception{
    public InvalidArgsExeption() {
        super("Invalid function args");
    }
}

